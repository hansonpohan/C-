-- 請練習撰寫底下指令，使用 Northwind 資料庫


-- Step1 確定打開的是 Northwind 資料庫 


-- Step2 列出 Products 產品資料表中欄位 ProductID, ProductName, SupplierID





-- Step3 承上題
--     請帶出該產品的供應商名稱(CompanyName)、聯絡電話(Phone)、聯絡人(ContactName)
--     相同供應商的資料請列在一起




-- Step4 承上題，請加入條件："庫存量低於再訂購量" 的產品資料





-- Step5 訂單的價格是否與產品的單價是否一致？




-- Step6. 那張訂單賺最多錢(折扣最小的)？




-- Step7. 找出訂單編號為10274所購買的產品清單，請找出產品名稱、產品價格





--	Steve 老師的提問社團 iCoding : https://www.facebook.com/groups/icoding
--  email : jungan0914@gmail.com
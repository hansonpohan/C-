-- 請練習撰寫底下指令 : 使用 Northwind.Customer 客戶資料表

-- Step 01 打開 Northwind 資料庫 



-- Step 02 從dbo.Customers table 中, 挑選 所有 客戶 資料




-- Step 03 挑選 所有 客戶 資料，並用城市City排序




-- Step 04 挑選 客戶 資料中指定欄位：CustomerID, CompanyName, ContactName, Phone



-- Step 05 延續上題，請將欄位名稱分別改成以中文 客戶編號, 公司名稱, 聯絡人, 連絡電話顯示




-- Step 06  挑選 客戶 資料中指定欄位：CustomerID, CompanyName, ContactName, Phone
--					挑選 城市國家是 德國






-- Step 07 承上題  
--					加入一欄位 ( Country +' , '+City) 並欄位名稱改成 'Country , City '
--					同時加入 國家墨西哥, 英國




-- Step 08 承上題  加入包含 CustomrID 中包含 AN 的資料






-- Step 09  承 Step 07  並依照 國家(大到小),  城市(小到大) 排序






--	Steve 老師的提問社團 iCoding : https://www.facebook.com/groups/icoding
--  email : jungan0914@gmail.com






-- 請練習撰寫底下指令 : 使用 Northwind.Products 產品資料表

-- Step1 確定打開的是 Northwind 資料庫 



-- Step2 請列出單價最高的前三項產品。



-- Step3 請列出產品的平均單價, 平均庫存, 平均在途。



-- Step4 請列出產品的最高單價, 最高庫存, 最高在途。




-- Step5 請列出各類產品的平均單價。



-- Step6 挑選類別編號(CategoryID)為 1, 4, 8 為範圍, 計算挑選範圍內產品的平均單價, 平均庫存, 平均在途。





-- Step7 請列出平均單價最高的前三類產品。




-- Step8 找出 價格最高 的產品 (使用 TOP 關鍵字)



-- Step9 找出 價格最低 的產品 (使用 TOP 關鍵字)



-- Step10 使用 MIN() 關鍵字改寫，取得價格最低產品單價是多少？




--	Steve 老師的提問社團 iCoding : https://www.facebook.com/groups/icoding
--  email : jungan0914@gmail.com




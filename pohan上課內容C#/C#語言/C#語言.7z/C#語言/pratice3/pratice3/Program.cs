﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pratice3
{
    class Program
    {
        static void Main(string[] args)
        {
            // 便當選單, 輸入便當名稱, 告訴使用者有沒有販售, 此便當多少錢
            // 建立2維string陣列, 儲存便當名稱跟價格, 做搜尋
            // 至少有十種便當, string[20, 2]

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pratice2
{
    class Program
    {
        static void Main(string[] args)
        {
            //用條件判斷式, 隨意輸入三個數字比大小;
            int a = 100;
            int b = 600;
            int c = 20;

        }
    }
}

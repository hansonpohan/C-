﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    interface IMan
    {
        string 顯示職稱(int 職稱代號);
    }
}
